<?php
$dbHost = 'localhost';
$dbName = 'agrishop';
$dbUsername = 'root';
$dbPassword = '';
$db= mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName); 
?>