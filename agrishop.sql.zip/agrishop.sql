-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2024 at 03:13 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agrishop`
--

-- --------------------------------------------------------

--
-- Table structure for table `bulkorder`
--

CREATE TABLE `bulkorder` (
  `id` int(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `productname` varchar(255) NOT NULL,
  `qty` int(30) NOT NULL,
  `email` varchar(150) NOT NULL,
  `formername` varchar(50) NOT NULL,
  `status` varchar(150) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `total` int(255) NOT NULL,
  `order_status` varchar(255) NOT NULL,
  `shipping_status` varchar(255) NOT NULL,
  `order_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cardname` varchar(255) NOT NULL,
  `cardnumb` int(16) NOT NULL,
  `emonth` int(2) NOT NULL,
  `eyear` int(4) NOT NULL,
  `cvv` int(3) NOT NULL,
  `price` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bulkorder`
--

INSERT INTO `bulkorder` (`id`, `name`, `address`, `category`, `productname`, `qty`, `email`, `formername`, `status`, `city`, `state`, `zip`, `total`, `order_status`, `shipping_status`, `order_at`, `cardname`, `cardnumb`, `emonth`, `eyear`, `cvv`, `price`) VALUES
(65, 'vanitha', 'Vijayashanthi', 'fruits', 'dragonfruit', 20, 'vanitha123@gmail.com', 'veeran', 'Accept', 'chennai', 'Tamil nadu', '602105', 16000, 'COMPLETE', 'PENDING', '2024-04-03 12:20:45', '', 0, 0, 0, 0, 800),
(66, 'vanitha', 'Vijayashanthi', 'fruits', 'guava', 10, 'vanitha123@gmail.com', 'vijay', 'Accept', 'chennai', 'Tamil nadu', '602105', 1500, 'COMPLETE', 'PENDING', '2024-01-29 08:30:45', '', 0, 0, 0, 0, 150),
(67, 'vanitha', 'Vijayashanthi', 'fruits', 'dragonfruit', 10, 'vanitha123@gmail.com', 'veeran', 'PENDING', 'chennai', 'Tamil nadu', '602105', 8000, 'COMPLETE', 'PENDING', '2024-01-15 10:48:20', '', 0, 0, 0, 0, 800),
(72, 'antony', 'giddalur', 'fruits', 'Apples', 16, 'antony@gmail.com', 'Peeraiah', 'PENDING', 'giddalur', 'ANDHRA PRADESH', '523373', 2240, 'COMPLETE', 'PENDING', '2024-01-16 10:48:01', '', 0, 0, 0, 0, 140),
(74, 'antony', 'sdevm ', 'fruits', 'Apples', 12, 'antony@gmail.com', 'Peeraiah', 'PENDING', 'ev', 'qeff', '334', 1680, 'COMPLETE', 'PENDING', '2024-01-16 10:53:10', '', 0, 0, 0, 0, 140),
(77, 'Sandeep ', 'Rice mill street', 'veg', 'Tomato', 12, 'sandeep@gmail.com', 'Sunil', 'Accept', 'Badvel', 'Andhra Pradesh', '405258', 480, 'COMPLETE', 'COMPLETE', '2024-01-31 10:26:23', '', 0, 0, 0, 0, 40),
(78, 'Sunil', 'Vijayashanthi', 'fruits', 'dragonfruit', 10, 'sunil@gmail.com', 'veeran', 'PENDING', 'chennai', 'Tamil nadu', '602105', 8000, 'COMPLETE', 'PENDING', '2024-01-25 10:18:45', '', 0, 0, 0, 0, 800),
(79, 'Sunil', 'Vijayashanthi', 'fruits', 'dragonfruit', 10, 'sunil@gmail.com', 'veeran', 'PENDING', 'chennai', 'Tamil nadu', '602105', 0, 'COMPLETE', 'PENDING', '2024-01-25 10:19:20', '', 0, 0, 0, 0, 800),
(80, 'Sunil', 'Vijayashanthi', 'veg', 'Raddish', 2, 'sunil@gmail.com', 'Sunil', 'ACCEPT', 'chennai', 'Tamil nadu', '602105', 156, 'COMPLETE', 'COMPLETE', '2024-01-25 10:36:27', '', 0, 0, 0, 0, 78),
(83, 'Sunil', 'SBI-road', 'veg', 'Raddish', 23, 'sunil@gmail.com', 'Sunil', 'PENDING', 'komarole', '4', '523373', 1794, 'COMPLETE', 'PENDING', '2024-01-25 10:49:43', '', 0, 0, 0, 0, 78),
(84, 'Sandeep', 'SBI-road', 'fruits', 'guava', 4, 'sandeep@gmail.com', 'vijay', 'Rejected', 'komarole', '4', '523373', 600, 'COMPLETE', 'PENDING', '2024-01-29 08:30:48', '', 0, 0, 0, 0, 150),
(91, 'antony', 'SBI-road', 'veg', 'tomato', 20, 'antony@gmail.com', 'ramya', 'PENDING', 'komarole', 'ANDHRA PRADESH', '523373', 0, 'COMPLETE', 'PENDING', '2024-01-29 06:51:42', '', 0, 0, 0, 0, 150),
(92, 'antony', 'SBI-road', 'veg', 'tomato', 10, 'antony@gmail.com', 'ramya', 'Accept', 'komarole', '4', '523373', 1500, 'COMPLETE', 'PENDING', '2024-01-29 06:53:52', '', 0, 0, 0, 0, 150),
(93, 'vanitha', 'HDfc', 'veg', 'Potato', 9, 'vanitha123@gmail.com', 'vijay', 'Accept', 'markapur', 'ANDHRA PRADESH', '523373', 432, 'COMPLETE', 'PENDING', '2024-01-29 08:30:27', '', 0, 0, 0, 0, 48),
(94, 'Uday', 'Vijayashanthi', 'fruits', 'Watermelon', 23, 'uday@gmail.com', 'Gnani', 'Accept', 'chennai', 'Tamil nadu', '602105', 644, 'COMPLETE', 'PENDING', '2024-01-31 06:36:14', '', 0, 0, 0, 0, 28),
(95, 'Uday', 'SBI-road', 'fruits', 'Pomegranate', 10, 'uday@gmail.com', 'Gnani', 'Rejected', 'komarole', '4', '523373', 800, 'COMPLETE', 'PENDING', '2024-01-30 03:39:34', '', 0, 0, 0, 0, 80),
(96, 'Uday', 'Vijayashanthi', 'fruits', 'Mango', 18, 'uday@gmail.com', 'Gnani', 'PENDING', 'chennai', 'Tamil nadu', '602105', 1440, 'COMPLETE', 'PENDING', '2024-02-02 14:00:40', '', 0, 0, 0, 0, 80),
(97, 'Deepthi', 'SBI-road', 'fruits', 'Apple', 10, 'deepthi@gmail.com', 'Nithesh', 'Accept', 'komarole', 'ANDHRA PRADESH', '523373', 850, 'COMPLETE', 'PENDING', '2024-02-03 06:19:10', '', 0, 0, 0, 0, 85),
(98, 'Deepthi', 'SBI-road', 'fruits', 'Mango', 7, 'deepthi@gmail.com', 'Gnani', 'PENDING', 'komarole', '4', '523373', 560, 'COMPLETE', 'PENDING', '2024-02-09 06:27:22', '', 0, 0, 0, 0, 80),
(99, 'antony', 'scdvmb', 'fruits', 'Apple', 7, 'antony@gmail.com', 'Nithesh', 'Accept', 'chennai', 'Tamil nadu', '602105', 595, 'COMPLETE', 'PENDING', '2024-02-29 04:38:09', '', 0, 0, 0, 0, 85),
(101, 'efg', 'Vijayashanthi', 'fruits', 'Apple', 7, 'efg@gmail.com', 'abc', 'Accept', 'chennai', 'Tamil nadu', '602105', 525, 'COMPLETE', 'PENDING', '2024-03-25 02:47:55', '', 0, 0, 0, 0, 75),
(102, 'manikandan', 'Vijayashanthi', 'fruits', 'Mango', 9, 'mani@gmail.com', 'Nithesh', 'PENDING', 'chennai', 'Tamil nadu', '602105', 945, 'COMPLETE', 'PENDING', '2024-04-24 14:58:12', '', 0, 0, 0, 0, 105);

-- --------------------------------------------------------

--
-- Table structure for table `former`
--

CREATE TABLE `former` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `role` text NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `former`
--

INSERT INTO `former` (`id`, `name`, `email`, `password`, `role`, `image`) VALUES
(14, 'ramya', 'ramya@gmail.com', '123456', 'former', 'profile_1446203623.jpg'),
(15, 'Vijay', 'vijay123@gmail.com', '444444', 'former', ''),
(16, 'veeran', 'veeran@gmail.com', '555555', 'former', 'cac.jpg'),
(18, 'Sunil', 'sunil@gmail.com', '123456', 'former', '1.jpg'),
(19, 'prasad1', 'prasad@gmail.com', '123456', 'former', ''),
(20, 'meena', 'meena@gmail.com', '123456', 'former', 'external-hard-drive.jpg'),
(21, 'Gnani', 'gnani@gmail.com', '123456', 'former', 'profile_26373315.jpg'),
(22, 'radha', 'radha@gmail.com', '1234567', 'former', 'maxresdefault.jpg'),
(23, 'Lakshmi', 'lakshmi@gmail.com', '123456', 'former', 'cac.jpg'),
(24, 'Jyothi', 'jyothi@gmail.com', '123456', 'former', '1.jpg'),
(25, 'Nithesh', 'nithesh@gmail.com', '123456', 'former', '1.jpg'),
(26, 'abc', 'abc@gmail.com', '123456', 'former', '1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(180) NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `payment_id` varchar(300) NOT NULL,
  `amount` varchar(150) NOT NULL,
  `product_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `payment_id`, `amount`, `product_id`) VALUES
(1, '1', 'pay_NTaKOatfaM5mbG', '397', '1'),
(2, '1', 'pay_NTaLnlJfaMP95R', '900', '1'),
(3, '1', 'pay_NUH35rSlDW5TGR', '930', '1'),
(4, '1', 'pay_NUMUMNngzBGROs', '1500', '1'),
(5, '1', 'pay_NUMdTv9LF11prl', '432', '1'),
(6, '1', 'pay_NUmQ7fkCFgcPii', '463', '1'),
(7, '1', 'pay_NVASrseDzMGNzn', '109', '1'),
(8, '1', 'pay_NVUp8nlLOhCZVd', '137', '1'),
(9, '1', 'pay_NVYPAN5HhKhFTv', '480', '1'),
(10, '1', 'pay_NWJ01bW1Fkr8yl', '850', '1'),
(11, '1', 'pay_NgYdTpi07kioJG', '176', '1'),
(12, '1', 'pay_NqQb7qjIypK0Fu', '800', '1'),
(13, '1', 'pay_NqQeGdJZKGsZYK', '525', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `member_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `payment_type` varchar(255) NOT NULL,
  `order_status` varchar(255) NOT NULL,
  `order_at` datetime NOT NULL,
  `email` varchar(150) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumb` int(16) NOT NULL,
  `emonth` int(2) NOT NULL,
  `eyear` int(4) NOT NULL,
  `cvv` int(3) NOT NULL,
  `userid` int(255) NOT NULL,
  `shipping_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `customer_id`, `amount`, `name`, `address`, `city`, `state`, `zip`, `country`, `payment_type`, `order_status`, `order_at`, `email`, `cardname`, `cardnumb`, `emonth`, `eyear`, `cvv`, `userid`, `shipping_status`) VALUES
(205, 2, 1300, 'mani', '45 sivaji 2nd street', 'vellore', 'bangalore', '12546', 'india', 'PAYPAL', 'COMPLETE', '2023-12-16 06:02:32', 'ramya@gmail.com', 'mani', 1, 1, 1, 1, 51, 'PENDING'),
(206, 2, 900, 'antony', 'no 12, ramasamy street, ram apartment', 'salem', 'bangalore', '123456', 'india', 'PAYPAL', 'COMPLETE', '2023-12-16 06:05:07', 'vanitha123@gmail.com', 'antony', 1, 1, 1, 1, 51, 'PENDING'),
(207, 2, 9750, 'antony', '45 sivaji 2nd street', 'chennai', 'tamilnadu', '600035', 'india', 'PAYPAL', 'COMPLETE', '2023-12-16 06:06:29', 'antony@gmail.com', 'antony', 1, 1, 1, 1, 51, 'PENDING'),
(208, 2, 3650, 'antony', 'no 12, ramasamy street, ram apartment', 'vellore', 'tamilnadu', '15248', 'india', 'PAYPAL', 'COMPLETE', '2023-12-16 06:10:34', 'antony@gmail.com', 'antony', 1, 1, 1, 1, 51, 'PENDING'),
(209, 2, 236, 'antony', 'chennai', 'chennai', 'tn', '600254', 'india', 'PAYPAL', 'COMPLETE', '2024-01-10 03:57:15', 'antony@gmail.com', 'antony', 1, 1, 1, 1, 51, 'PENDING'),
(210, 2, 622, 'mano', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-10 07:35:17', 'mano@gmail.com', 'mano', 2147483647, 7, 2028, 133, 62, 'PENDING'),
(211, 2, 150, 'mano', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-10 07:50:53', 'mano@gmail.com', 'mano', 126709, 9, 2028, 197, 62, 'PENDING'),
(212, 2, 150, 'mano', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-10 10:19:15', 'mano@gmail.com', '', 0, 0, 0, 0, 62, 'PENDING'),
(213, 2, 644, 'mano', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-10 10:24:24', 'mano@gmail.com', '', 0, 0, 0, 0, 62, 'PENDING'),
(214, 2, 794, 'mano', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-10 10:24:55', 'mano@gmail.com', '', 0, 0, 0, 0, 62, 'PENDING'),
(215, 2, 794, 'manikandan', 'chettiped', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-11 10:33:31', 'mani@gmail.com', '', 0, 0, 0, 0, 55, 'PENDING'),
(216, 2, 1644, 'manikandan', 'chen', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-11 10:34:09', 'mani@gmail.com', '', 0, 0, 0, 0, 55, 'PENDING'),
(217, 2, 1236, 'vanitha', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-15 11:47:15', 'vanitha123@gmail.com', '', 0, 0, 0, 0, 50, 'PENDING'),
(231, 2, 260, 'Sandeep kumar', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-16 11:36:23', 'sandeep@gmail.com', '', 0, 0, 0, 0, 56, 'PENDING'),
(236, 2, 500, 'antony', 'giddalur', 'giddalur', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-16 11:48:43', 'antony@gmail.com', '', 0, 0, 0, 0, 51, 'PENDING'),
(239, 2, 100, 'antony', 'efmwr', '22f42i', '2442f', '24fm', '2fm', 'PAYPAL', 'COMPLETE', '2024-01-16 11:51:46', 'antony@gmail.com', '', 0, 0, 0, 0, 51, 'PENDING'),
(242, 2, 650, 'vanitha', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-16 12:11:45', 'vanitha123@gmail.com', '', 0, 0, 0, 0, 50, 'PENDING'),
(243, 2, 300, 'manikandan', 'gfdg', 'jnku', 'hgiu', 'jiiuh', 'lij', 'PAYPAL', 'COMPLETE', '2024-01-21 06:14:33', 'mani@gmail.com', '', 0, 0, 0, 0, 55, 'PENDING'),
(244, 2, 300, 'manikandan', 'gfdg', 'jnku', 'hgiu', 'jiiuh', 'lij', 'PAYPAL', 'COMPLETE', '2024-01-21 06:15:08', 'mani@gmail.com', '', 0, 0, 0, 0, 55, 'PENDING'),
(245, 2, 300, 'manikandan', 'gfdg', 'jnku', 'hgiu', 'jiiuh', 'lij', 'PAYPAL', 'COMPLETE', '2024-01-21 06:15:39', 'mani@gmail.com', '', 0, 0, 0, 0, 55, 'PENDING'),
(246, 2, 300, 'manikandan', 'gfdg', 'jnku', 'hgiu', 'jiiuh', 'lij', 'PAYPAL', 'COMPLETE', '2024-01-21 06:21:41', 'mani@gmail.com', '', 0, 0, 0, 0, 55, 'PENDING'),
(247, 2, 40, 'Sandeep ', 'Rice mill street', 'Badvel', 'ANDHRA PRADESH', '405258', 'India', 'PAYPAL', 'COMPLETE', '2024-01-21 06:41:07', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(248, 2, 647, 'Sandeep ', 'Rice mill street', 'Badvel', 'Andhra pradesh', '405258', 'India', 'PAYPAL', 'COMPLETE', '2024-01-21 06:46:09', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(251, 2, 647, 'Sandeep ', 'sidc', 'ekmwe', 'qeqem', '243456', 'efwr', 'PAYPAL', 'COMPLETE', '2024-01-21 06:54:25', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(252, 2, 647, 'Sandeep ', 'sidc', 'ekmwe', 'qeqem', '243456', 'efwr', 'PAYPAL', 'COMPLETE', '2024-01-21 06:55:06', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(253, 2, 647, 'Sandeep ', 'sidc', 'ekmwe', 'qeqem', '243456', 'efwr', 'PAYPAL', 'COMPLETE', '2024-01-21 06:55:19', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(254, 2, 1147, 'Sandeep ', 'kj', 'kgiu', 'iyiui', '9754', 'fdtti', 'PAYPAL', 'COMPLETE', '2024-01-21 06:55:57', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(255, 2, 1300, 'vanitha', 'Gandhi nagar', 'Markapur', 'Andhra pradesh', '279046', 'India', 'PAYPAL', 'COMPLETE', '2024-01-21 07:00:34', 'vanitha123@gmail.com', '', 0, 0, 0, 0, 50, 'PENDING'),
(256, 2, 147, 'Sandeep', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-25 04:50:31', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(257, 2, 247, 'Sandeep', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-25 04:51:36', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(258, 2, 247, 'Sunil', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-25 10:06:47', 'sunil@gmail.com', '', 0, 0, 0, 0, 59, 'PENDING'),
(259, 2, 120, 'Sunil', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-25 10:07:28', 'sunil@gmail.com', '', 0, 0, 0, 0, 59, 'PENDING'),
(260, 2, 120, 'Sunil', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-25 10:07:57', 'sunil@gmail.com', '', 0, 0, 0, 0, 59, 'PENDING'),
(261, 2, 878, 'Sandeep', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-25 10:27:38', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(262, 2, 150, 'Sandeep', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-25 10:28:35', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(263, 2, 375, 'antony', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-26 10:01:17', 'antony@gmail.com', '', 0, 0, 0, 0, 51, 'PENDING'),
(264, 2, 225, 'antony', 'addnfge', 'wfvmf', 'wrvkwrg', 'rvwr', 'wrrg', 'PAYPAL', 'COMPLETE', '2024-01-26 10:04:23', 'antony@gmail.com', '', 0, 0, 0, 0, 51, 'PENDING'),
(265, 2, 57, 'Balu', 'HDFC Road', 'Kodur', 'ANDHRA PRADESH', '386741', 'India', 'PAYPAL', 'COMPLETE', '2024-01-26 15:03:16', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(266, 2, 264, 'Balu', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:15:32', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(267, 2, 300, 'Balu', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:34:29', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(268, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:38:06', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(269, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:38:31', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(270, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:46:07', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(271, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:46:18', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(272, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:46:57', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(273, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:48:00', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(274, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:48:16', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(275, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:49:41', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(276, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:50:07', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(277, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:51:03', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(278, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:53:32', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(279, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:53:59', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(280, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:54:46', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(281, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 07:56:10', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(282, 2, 1047, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:26:37', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(283, 2, 1197, 'Balu', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:28:36', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(284, 2, 1197, 'Balu', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:31:13', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(285, 2, 1347, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:31:44', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(286, 2, 1347, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:32:59', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(287, 2, 1347, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:33:32', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(288, 2, 1347, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:34:34', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(289, 2, 1347, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:34:44', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(290, 2, 1347, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:35:40', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(291, 2, 547, 'Balu', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:36:11', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(292, 2, 547, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:38:16', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(293, 2, 547, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:39:27', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(294, 2, 697, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:50:55', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(295, 2, 697, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:54:27', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(296, 2, 697, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 09:58:42', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(297, 2, 397, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 10:01:43', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(298, 2, 397, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 10:09:53', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(299, 2, 397, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 10:14:18', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(300, 2, 397, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 10:19:37', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(301, 2, 900, 'Balu', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-27 10:20:58', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(302, 2, 900, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-29 03:36:43', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(303, 2, 900, 'Balu', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-29 03:36:54', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(304, 2, 930, 'Sandeep', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-01-29 04:07:02', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(305, 2, 0, 'antony', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-29 09:19:12', 'antony@gmail.com', '', 0, 0, 0, 0, 51, 'PENDING'),
(306, 2, 48, 'mano', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-29 09:20:58', 'mano@gmail.com', '', 0, 0, 0, 0, 63, 'PENDING'),
(307, 2, 100, 'Uday', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-30 04:32:34', 'uday@gmail.com', '', 0, 0, 0, 0, 64, 'PENDING'),
(308, 2, 1400, 'ramya', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-30 10:42:32', 'ramya@gmail.com', '', 0, 0, 0, 0, 52, 'PENDING'),
(309, 2, 463, 'Uday', 'MGR', 'Kadapa', 'ANDHRA PRADESH', '724590', 'India', 'PAYPAL', 'COMPLETE', '2024-01-30 10:46:18', 'uday@gmail.com', '', 0, 0, 0, 0, 64, 'PENDING'),
(310, 2, 463, 'Uday', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-01-30 10:48:04', 'uday@gmail.com', '', 0, 0, 0, 0, 64, 'PENDING'),
(311, 2, 109, 'Balu', 'dvfvf ', 'vrflrg', 'Andhra Pradesh', '396265', 'INDIA', 'PAYPAL', 'COMPLETE', '2024-01-31 10:19:17', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING'),
(312, 2, 68, 'Uday', 'ABR road', 'Kadapa', 'Andhra pradesh', '208145', 'India', 'PAYPAL', 'COMPLETE', '2024-02-01 04:18:07', 'uday@gmail.com', '', 0, 0, 0, 0, 64, 'PENDING'),
(313, 2, 68, 'Uday', 'ABR road', 'Kadapa', 'Andhra pradesh', '208145', 'India', 'PAYPAL', 'COMPLETE', '2024-02-01 04:21:03', 'uday@gmail.com', '', 0, 0, 0, 0, 64, 'PENDING'),
(314, 2, 68, 'Uday', 'ABR road', 'Kadapa', 'Andhra pradesh', '208145', 'India', 'PAYPAL', 'COMPLETE', '2024-02-01 04:22:17', 'uday@gmail.com', '', 0, 0, 0, 0, 64, 'PENDING'),
(315, 2, 137, 'Uday', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-02-01 06:07:39', 'uday@gmail.com', '', 0, 0, 0, 0, 64, 'PENDING'),
(316, 2, 78, 'Uday', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-02-01 06:36:05', 'uday@gmail.com', '', 0, 0, 0, 0, 64, 'PENDING'),
(317, 2, 78, 'Uday', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-02-01 06:36:33', 'uday@gmail.com', '', 0, 0, 0, 0, 64, 'PENDING'),
(318, 2, 78, 'Uday', 'SBI-road', 'komarole', '4', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-02-01 06:37:45', 'uday@gmail.com', '', 0, 0, 0, 0, 64, 'PENDING'),
(319, 2, 176, 'antony', 'svnsdgmh', 'chennai', 'tamilnadu', '482757', 'india', 'PAYPAL', 'COMPLETE', '2024-02-29 05:04:44', 'antony@gmail.com', '', 0, 0, 0, 0, 51, 'PENDING'),
(320, 2, 176, 'antony', 'svnsdgmh', 'chennai', 'tamilnadu', '482757', 'india', 'PAYPAL', 'COMPLETE', '2024-02-29 05:07:04', 'antony@gmail.com', '', 0, 0, 0, 0, 51, 'PENDING'),
(321, 2, 1600, 'Sandeep', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-03-01 06:53:11', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(322, 2, 1600, 'Sandeep', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-03-01 06:54:19', 'sandeep@gmail.com', '', 0, 0, 0, 0, 58, 'PENDING'),
(323, 2, 800, 'efg', 'Vijayashanthi', 'chennai', 'Tamil nadu', '602105', 'India', 'PAYPAL', 'COMPLETE', '2024-03-25 03:45:22', 'efg@gmail.com', '', 0, 0, 0, 0, 73, 'PENDING'),
(324, 2, 520, 'antony', 'SBI-road', 'komarole', 'ANDHRA PRADESH', '523373', 'India', 'PAYPAL', 'COMPLETE', '2024-04-03 18:29:52', 'antony@gmail.com', '', 0, 0, 0, 0, 51, 'PENDING'),
(325, 2, 190, 'Balu', 'railway kodur', 'Kodur', 'ANDHRA PRADESH', '329573', 'India', 'PAYPAL', 'COMPLETE', '2024-04-14 17:36:52', 'balu@gmail.com', '', 0, 0, 0, 0, 61, 'PENDING');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_item`
--

CREATE TABLE `tbl_order_item` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `item_price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `userid` int(255) NOT NULL,
  `shipping_status` varchar(255) NOT NULL,
  `order_status` varchar(255) NOT NULL,
  `totalprice` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_order_item`
--

INSERT INTO `tbl_order_item` (`id`, `order_id`, `product_id`, `item_price`, `quantity`, `name`, `userid`, `shipping_status`, `order_status`, `totalprice`) VALUES
(292, 207, 36, 500, 1, 'antony', 51, 'COMPLETE', 'COMPLETE', 500),
(295, 208, 34, 150, 1, 'antony', 51, 'COMPLETE', 'COMPLETE', 150),
(300, 212, 32, 150, 1, 'mano', 62, 'PENDING', 'COMPLETE', 150),
(301, 213, 33, 350, 1, 'mano', 62, 'PENDING', 'COMPLETE', 350),
(302, 213, 35, 147, 2, 'mano', 62, 'COMPLETE', 'COMPLETE', 294),
(305, 214, 34, 150, 1, 'mano', 62, 'COMPLETE', 'COMPLETE', 150),
(307, 215, 36, 500, 1, 'manikandan', 55, 'COMPLETE', 'COMPLETE', 500),
(309, 216, 36, 500, 2, 'manikandan', 55, 'COMPLETE', 'COMPLETE', 1000),
(311, 217, 33, 350, 2, 'vanitha', 50, 'PENDING', 'COMPLETE', 700),
(312, 217, 34, 150, 2, 'vanitha', 50, 'COMPLETE', 'COMPLETE', 300),
(313, 217, 30, 236, 1, 'vanitha', 50, 'PENDING', 'COMPLETE', 236),
(337, 233, 40, 20, 1, 'manikandan', 55, 'PENDING', 'COMPLETE', 20),
(338, 233, 41, 140, 1, 'manikandan', 55, 'PENDING', 'COMPLETE', 140),
(343, 236, 38, 100, 1, 'antony', 51, 'PENDING', 'COMPLETE', 100),
(345, 237, 38, 100, 1, 'antony', 51, 'PENDING', 'COMPLETE', 100),
(346, 238, 38, 100, 1, 'antony', 51, 'PENDING', 'COMPLETE', 100),
(347, 239, 38, 100, 1, 'antony', 51, 'PENDING', 'COMPLETE', 100),
(348, 240, 38, 100, 1, 'antony', 51, 'PENDING', 'COMPLETE', 100),
(350, 242, 38, 100, 1, 'vanitha', 50, 'PENDING', 'COMPLETE', 100),
(351, 242, 37, 400, 1, 'vanitha', 50, 'PENDING', 'COMPLETE', 400),
(352, 242, 34, 150, 1, 'vanitha', 50, 'COMPLETE', 'COMPLETE', 150),
(353, 243, 32, 150, 1, 'manikandan', 55, 'PENDING', 'COMPLETE', 150),
(354, 243, 34, 150, 1, 'manikandan', 55, 'COMPLETE', 'COMPLETE', 150),
(355, 244, 32, 150, 1, 'manikandan', 55, 'PENDING', 'COMPLETE', 150),
(356, 244, 34, 150, 1, 'manikandan', 55, 'COMPLETE', 'COMPLETE', 150),
(357, 245, 32, 150, 1, 'manikandan', 55, 'PENDING', 'COMPLETE', 150),
(358, 245, 34, 150, 1, 'manikandan', 55, 'COMPLETE', 'COMPLETE', 150),
(359, 246, 32, 150, 1, 'manikandan', 55, 'PENDING', 'COMPLETE', 150),
(360, 246, 34, 150, 1, 'manikandan', 55, 'COMPLETE', 'COMPLETE', 150),
(361, 247, 42, 40, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 40),
(362, 248, 36, 500, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 500),
(363, 248, 35, 147, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 147),
(364, 249, 36, 500, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 500),
(365, 249, 35, 147, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 147),
(366, 250, 36, 500, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 500),
(367, 250, 35, 147, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 147),
(368, 251, 36, 500, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 500),
(369, 251, 35, 147, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 147),
(370, 252, 36, 500, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 500),
(371, 252, 35, 147, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 147),
(372, 253, 36, 500, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 500),
(373, 253, 35, 147, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 147),
(374, 254, 36, 500, 2, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 1000),
(375, 254, 35, 147, 1, 'Sandeep ', 58, 'COMPLETE', 'COMPLETE', 147),
(376, 255, 39, 800, 1, 'vanitha', 50, 'PENDING', 'COMPLETE', 800),
(377, 255, 36, 500, 1, 'vanitha', 50, 'COMPLETE', 'COMPLETE', 500),
(378, 256, 35, 147, 1, 'Sandeep', 58, 'COMPLETE', 'COMPLETE', 147),
(379, 257, 35, 147, 1, 'Sandeep', 58, 'COMPLETE', 'COMPLETE', 147),
(380, 257, 38, 100, 1, 'Sandeep', 58, 'PENDING', 'COMPLETE', 100),
(381, 258, 35, 147, 1, 'Sunil', 59, 'COMPLETE', 'COMPLETE', 147),
(382, 258, 38, 100, 1, 'Sunil', 59, 'PENDING', 'COMPLETE', 100),
(383, 259, 42, 40, 3, 'Sunil', 59, 'COMPLETE', 'COMPLETE', 120),
(384, 260, 42, 40, 3, 'Sunil', 59, 'COMPLETE', 'COMPLETE', 120),
(385, 261, 39, 800, 1, 'Sandeep', 58, 'PENDING', 'COMPLETE', 800),
(386, 261, 43, 78, 1, 'Sandeep', 58, 'PENDING', 'COMPLETE', 78),
(387, 262, 34, 150, 1, 'Sandeep', 58, 'COMPLETE', 'COMPLETE', 150),
(388, 263, 43, 78, 1, 'antony', 51, 'PENDING', 'COMPLETE', 78),
(389, 263, 35, 147, 1, 'antony', 51, 'COMPLETE', 'COMPLETE', 147),
(390, 263, 34, 150, 1, 'antony', 51, 'PENDING', 'COMPLETE', 150),
(391, 264, 43, 78, 1, 'antony', 51, 'PENDING', 'COMPLETE', 78),
(392, 264, 35, 147, 1, 'antony', 51, 'COMPLETE', 'COMPLETE', 147),
(393, 265, 45, 57, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 57),
(394, 266, 45, 57, 2, 'Balu', 61, 'PENDING', 'COMPLETE', 114),
(395, 266, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(396, 267, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(397, 267, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(398, 268, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(399, 268, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(400, 268, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(401, 269, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(402, 269, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(403, 269, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(404, 270, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(405, 270, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(406, 270, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(407, 271, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(408, 271, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(409, 271, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(410, 272, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(411, 272, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(412, 272, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(413, 273, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(414, 273, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(415, 273, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(416, 274, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(417, 274, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(418, 274, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(419, 275, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(420, 275, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(421, 275, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(422, 276, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(423, 276, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(424, 276, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(425, 277, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(426, 277, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(427, 277, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(428, 278, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(429, 278, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(430, 278, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(431, 279, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(432, 279, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(433, 279, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(434, 280, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(435, 280, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(436, 280, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(437, 281, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(438, 281, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(439, 281, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(440, 282, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(441, 282, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(442, 282, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(443, 283, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(444, 283, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(445, 283, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(446, 283, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(447, 284, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(448, 284, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(449, 284, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(450, 284, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(451, 285, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(452, 285, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(453, 285, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(454, 285, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(455, 285, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(456, 286, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(457, 286, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(458, 286, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(459, 286, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(460, 286, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(461, 287, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(462, 287, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(463, 287, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(464, 287, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(465, 287, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(466, 288, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(467, 288, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(468, 288, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(469, 288, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(470, 288, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(471, 289, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(472, 289, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(473, 289, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(474, 289, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(475, 289, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(476, 290, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(477, 290, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(478, 290, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(479, 290, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(480, 290, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(481, 291, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(482, 291, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(483, 291, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(484, 291, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(485, 292, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(486, 292, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(487, 292, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(488, 292, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(489, 293, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(490, 293, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(491, 293, 34, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(492, 293, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(493, 294, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(494, 294, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(495, 294, 34, 150, 2, 'Balu', 61, 'PENDING', 'COMPLETE', 300),
(496, 294, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(497, 295, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(498, 295, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(499, 295, 34, 150, 2, 'Balu', 61, 'PENDING', 'COMPLETE', 300),
(500, 295, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(501, 296, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(502, 296, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(503, 296, 34, 150, 2, 'Balu', 61, 'PENDING', 'COMPLETE', 300),
(504, 296, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(505, 297, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(506, 297, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(507, 297, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(508, 298, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(509, 298, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(510, 298, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(511, 299, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(512, 299, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(513, 299, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(514, 300, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(515, 300, 35, 147, 1, 'Balu', 61, 'COMPLETE', 'COMPLETE', 147),
(516, 300, 32, 150, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 150),
(517, 301, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(518, 301, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(519, 302, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(520, 302, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(521, 303, 38, 100, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 100),
(522, 303, 39, 800, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 800),
(523, 304, 39, 800, 1, 'Sandeep', 58, 'PENDING', 'COMPLETE', 800),
(524, 304, 47, 30, 1, 'Sandeep', 58, 'PENDING', 'COMPLETE', 30),
(525, 304, 38, 100, 1, 'Sandeep', 58, 'PENDING', 'COMPLETE', 100),
(526, 306, 46, 48, 1, 'mano', 63, 'PENDING', 'COMPLETE', 48),
(527, 307, 38, 100, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 100),
(528, 308, 38, 100, 1, 'ramya', 52, 'PENDING', 'COMPLETE', 100),
(529, 308, 39, 800, 1, 'ramya', 52, 'PENDING', 'COMPLETE', 800),
(530, 308, 36, 500, 1, 'ramya', 52, 'PENDING', 'COMPLETE', 500),
(531, 309, 35, 147, 1, 'Uday', 64, 'COMPLETE', 'COMPLETE', 147),
(532, 309, 50, 80, 1, 'Uday', 64, 'REJECTED', 'REFUND', 80),
(533, 309, 48, 80, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 80),
(534, 309, 43, 78, 2, 'Uday', 64, 'PENDING', 'COMPLETE', 156),
(535, 310, 35, 147, 1, 'Uday', 64, 'COMPLETE', 'COMPLETE', 147),
(536, 310, 50, 80, 1, 'Uday', 64, 'REJECTED', 'REFUND', 80),
(537, 310, 48, 80, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 80),
(538, 310, 43, 78, 2, 'Uday', 64, 'PENDING', 'COMPLETE', 156),
(539, 311, 47, 30, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 30),
(540, 311, 51, 79, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 79),
(541, 312, 42, 40, 1, 'Uday', 64, 'COMPLETE', 'COMPLETE', 40),
(542, 312, 49, 28, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 28),
(543, 313, 42, 40, 1, 'Uday', 64, 'COMPLETE', 'COMPLETE', 40),
(544, 313, 49, 28, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 28),
(545, 314, 42, 40, 1, 'Uday', 64, 'COMPLETE', 'COMPLETE', 40),
(546, 314, 49, 28, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 28),
(547, 315, 45, 57, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 57),
(548, 315, 50, 80, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 80),
(549, 316, 46, 48, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 48),
(550, 316, 47, 30, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 30),
(551, 317, 46, 48, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 48),
(552, 317, 47, 30, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 30),
(553, 318, 46, 48, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 48),
(554, 318, 47, 30, 1, 'Uday', 64, 'PENDING', 'COMPLETE', 30),
(555, 319, 46, 48, 2, 'antony', 51, 'PENDING', 'COMPLETE', 96),
(556, 319, 50, 80, 1, 'antony', 51, 'PENDING', 'COMPLETE', 80),
(557, 320, 46, 48, 2, 'antony', 51, 'PENDING', 'COMPLETE', 96),
(558, 320, 50, 80, 1, 'antony', 51, 'PENDING', 'COMPLETE', 80),
(559, 321, 39, 800, 2, 'Sandeep', 58, 'PENDING', 'COMPLETE', 1600),
(560, 322, 39, 800, 2, 'Sandeep', 58, 'PENDING', 'COMPLETE', 1600),
(561, 323, 39, 800, 1, 'efg', 73, 'PENDING', 'COMPLETE', 800),
(562, 324, 36, 490, 1, 'antony', 51, 'PENDING', 'COMPLETE', 490),
(563, 324, 47, 30, 1, 'antony', 51, 'PENDING', 'COMPLETE', 30),
(564, 325, 56, 105, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 105),
(565, 325, 55, 85, 1, 'Balu', 61, 'PENDING', 'COMPLETE', 85);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `payment_response` text NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(8) NOT NULL,
  `productname` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL,
  `category` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `formerid` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `productname`, `code`, `image`, `price`, `category`, `name`, `formerid`) VALUES
(32, 'guava', '343dfd', 'guava.jpg', 150.00, 'fruits', 'vijay', 53),
(34, 'tomato', 'tomato584', 'tomato.jpg', 150.00, 'veg', 'ramya', 52),
(35, 'banana', 'bana459', 'banana.jpg', 147.00, 'fruits', 'ramya', 52),
(36, 'bottleguard', 'BOTT123', 'bottleguard.jpg', 490.00, 'veg', 'ramya', 52),
(38, 'green', 'GRE143', 'of10.png', 100.00, 'veg', 'vijay', 53),
(39, 'dragonfruit', 'DRG001', 'dragonfruit.jpg', 800.00, 'fruits', 'veeran', 54),
(42, 'Tomato', 'TM5', 'tomato.jpg', 40.00, 'veg', 'Sunil', 59),
(43, 'Raddish', 'RD102', 'raddish.jpg', 78.00, 'veg', 'Sunil', 59),
(45, 'Cucumber', 'CU14', 'page2_img3.jpg', 57.00, 'veg', 'Prasad', 60),
(46, 'Potato', 'PT19', 'potato.jpeg', 48.00, 'veg', 'vijay', 53),
(47, 'Onion', 'ON96', 'onionjpeg.jpeg', 30.00, 'veg', 'prasad', 60),
(48, 'Mango', 'MN18', 'mango.jpg', 80.00, 'fruits', 'Gnani', 65),
(49, 'Watermelon', 'WM10', 'watermelon.jpg', 28.00, 'fruits', 'Gnani', 65),
(50, 'Pomegranate', 'PM68', 'pomegranate.jpg', 80.00, 'fruits', 'Gnani', 65),
(51, 'Orange', 'OR28', 'orange.jpg', 85.00, 'fruits', 'ramya', 52),
(54, 'guava', 'GV10', 'guava.jpg', 100.00, 'fruits', 'Gnani', 65),
(55, 'Apple', 'AP220', 'apples.jpg', 85.00, 'fruits', 'Nithesh', 70),
(56, 'Mango', 'MN16', 'mango.jpg', 105.00, 'fruits', 'Nithesh', 70),
(57, 'Apple', 'AP18', 'apples.jpg', 75.00, 'fruits', 'abc', 72);

-- --------------------------------------------------------

--
-- Table structure for table `temp_cart`
--

CREATE TABLE `temp_cart` (
  `id` int(255) NOT NULL,
  `productid` int(255) NOT NULL,
  `userid` int(255) NOT NULL,
  `qty` int(255) NOT NULL,
  `price` int(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `temp_cart`
--

INSERT INTO `temp_cart` (`id`, `productid`, `userid`, `qty`, `price`, `status`) VALUES
(276, 39, 3, 1, 800, 'oncart'),
(277, 38, 3, 1, 100, 'oncart'),
(280, 37, 51, 1, 400, 'oncart'),
(281, 37, 51, 1, 400, 'oncart'),
(282, 38, 51, 1, 100, 'oncart'),
(283, 38, 51, 1, 100, 'oncart'),
(284, 37, 54, 1, 400, 'oncart'),
(285, 39, 54, 1, 800, 'oncart'),
(286, 35, 54, 1, 147, 'oncart'),
(289, 38, 55, 1, 100, 'oncart'),
(300, 39, 55, 1, 800, 'oncart'),
(305, 39, 58, 1, 800, 'oncart');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(150) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `role`, `image`) VALUES
(50, 'vanitha', 'vanitha123@gmail.com', '123456', 'user', 'maxresdefault.jpg'),
(51, 'antony', 'antony@gmail.com', '456789', 'user', '1.jpg'),
(52, 'ramya', 'ramya@gmail.com', '123456', 'former', 'profile_1446203623.jpg'),
(53, 'vijay', 'vijay123@gmail.com', '444444', 'former', 'profile_26373315.jpg'),
(54, 'veeran', 'veeran@gmail.com', '555555', 'former', 'cac.jpg'),
(55, 'manikandan', 'mani@gmail.com', '123456', 'user', '1.jpg'),
(58, 'Sandeep', 'sandeep@gmail.com', '123456', 'user', 'cac.jpg'),
(59, 'Sunil', 'sunil@gmail.com', '123456', 'former', '1.jpg'),
(60, 'prasad', 'prasad@gmail.com', '123456', 'former', '1.jpg'),
(61, 'Balu', 'balu@gmail.com', '123456', 'user', '1.jpg'),
(62, 'meena', 'meena@gmail.com', '123456', 'former', 'external-hard-drive.jpg'),
(63, 'mano', 'mano@gmail.com', '123456', 'user', 'building-1080596_960_720.jpg'),
(64, 'Uday', 'uday@gmail.com', '123456', 'user', 'building-1080596_960_720.jpg'),
(65, 'Gnani', 'gnani@gmail.com', '123456', 'former', 'profile_26373315.jpg'),
(66, 'radha', 'radha@gmail.com', '1234567', 'former', 'maxresdefault.jpg'),
(67, 'Lakshmi', 'lakshmi@gmail.com', '123456', 'former', 'cac.jpg'),
(68, 'Jyothi', 'jyothi@gmail.com', '123456', 'former', '1.jpg'),
(69, 'Hafeez', 'hafeez@gmail.com', '123456', 'user', '1.jpg'),
(70, 'Nithesh', 'nithesh@gmail.com', '123456', 'former', '1.jpg'),
(71, 'Deepthi', 'deepthi@gmail.com', '123456', 'user', 'building-1080596_960_720.jpg'),
(72, 'abc', 'abc@gmail.com', '123456', 'former', '1.jpg'),
(73, 'efg', 'efg@gmail.com', '123456', 'user', 'building-1080596_960_720.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bulkorder`
--
ALTER TABLE `bulkorder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `former`
--
ALTER TABLE `former`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order_item`
--
ALTER TABLE `tbl_order_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_code` (`code`);

--
-- Indexes for table `temp_cart`
--
ALTER TABLE `temp_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bulkorder`
--
ALTER TABLE `bulkorder`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `former`
--
ALTER TABLE `former`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(180) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=479;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=326;

--
-- AUTO_INCREMENT for table `tbl_order_item`
--
ALTER TABLE `tbl_order_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=566;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `temp_cart`
--
ALTER TABLE `temp_cart`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=306;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
